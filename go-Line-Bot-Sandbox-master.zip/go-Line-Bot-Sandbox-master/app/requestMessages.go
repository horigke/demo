package app

const NormalMessage = "normalMessage"
const LocationMessage = "locationMessage"
const ImageMessage = "ImageMessage"
const CarouselMessage = "carouselMessage"
const MoreSelect = "moreSelectlMessage"

const CarouselMessageSelectA = "CarouselMessageSelectA"
const CarouselMessageSelectB = "CarouselMessageSelectB"
const CarouselMessageSelectC = "CarouselMessageSelectC"
const CarouselMessageSelectD = "CarouselMessageSelectD"