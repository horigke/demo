# Line-Bot-Sandbox
AppEngine and GoLang  

## Image
![20170228233709](https://user-images.githubusercontent.com/181991/28682471-0baf9d90-7338-11e7-8a8a-5b5f74509657.png)


## Serve
```
export PATH=~/go_appengine:$PATH
goapp serve ./app
```

## Deploy
```
export PATH=~/go_appengine:$PATH
goapp deploy  ./app/
```
